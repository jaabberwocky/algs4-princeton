import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {

    public PercolationStats(int n, int trials) {
        Percolation perc = new Percolation(n);


    }
}
